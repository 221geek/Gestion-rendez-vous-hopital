<?php
    require "../app/class/database.class.php";
    require "../app/class/Form.class.php";