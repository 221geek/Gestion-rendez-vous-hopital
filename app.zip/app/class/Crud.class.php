<?php

    

    class Crud extends Database
    {

    }