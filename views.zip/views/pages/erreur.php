<?php
    $title = "Page introuvable";
?>

<div class="error404"></div>